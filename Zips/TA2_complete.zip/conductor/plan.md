# Plan: Implementación de Aplicación de Usuarios

Este plan detalla los pasos para cumplir con los requisitos del laboratorio, incluyendo la creación de formularios, navegación entre actividades, uso de RecyclerView e Intents implícitos.

## 1. Modelo de Datos
- Crear la clase `Usuario.java` en `com.example.practica`.
- Campos: `String nombre`, `int edad`, `String correo`.
- Implementar `Serializable` para facilitar el paso de datos entre actividades.

## 2. Dependencias y Configuración
- Agregar `recyclerview` a `libs.versions.toml` y `app/build.gradle.kts`.
- Registrar `DetalleActivity` y `ListaActivity` en `AndroidManifest.xml`.

## 3. Recursos de UI
- **Menú**: Actualizar `res/menu/main_menu.xml` con las opciones:
    - `action_agregar` (Agregar usuario)
    - `action_lista` (Lista de usuarios)
    - `action_salir` (Cerrar sesión)
- **Layouts**:
    - `activity_main.xml`: Formulario con 3 `EditText` (Nombre, Edad, Correo) y un `Button` (Enviar). Incluir Toolbar.
    - `activity_detalle.xml`: `TextViews` para mostrar los datos. Botón "Editar" y Botón "Enviar Correo" (Intent implícito).
    - `activity_lista.xml`: `RecyclerView` para mostrar la lista.
    - `item_usuario.xml`: Diseño de fila para el RecyclerView (Nombre y Correo).

## 4. Actividades y Lógica
- **MainActivity.java**:
    - Inicializar Toolbar y Menú.
    - Implementar lógica para abrir formulario y lista desde el menú.
    - Capturar datos del formulario y enviarlos a `DetalleActivity`.
    - Implementar `onActivityResult` para manejar el retorno desde `DetalleActivity`.
- **DetalleActivity.java**:
    - Recibir y mostrar datos del `Usuario`.
    - Botón "Editar": Retornar el objeto `Usuario` a `MainActivity` usando `setResult`.
    - Botón "Acción": Implementar `ACTION_SENDTO` para enviar un correo.
- **ListaActivity.java**:
    - Configurar `RecyclerView` con `LinearLayoutManager`.
    - Crear un `ArrayList<Usuario>` con datos de prueba.
    - Implementar `UsuarioAdapter` (clase interna o separada).

## 5. Verificación
- Abrir la app y verificar que la Toolbar muestra el menú.
- Llenar el formulario y navegar a `DetalleActivity`.
- Regresar a `MainActivity` mediante "Editar" y verificar que los datos se mantienen.
- Abrir `ListaActivity` y verificar que los usuarios se listan correctamente.
- Probar el botón de enviar correo en `DetalleActivity`.
